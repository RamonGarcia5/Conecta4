package javafxmlapplication;

import java.io.File;
import java.net.URL;
import java.time.LocalDate;
import java.time.Period;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Ramon
 */
public class RegisterPanelController implements Initializable {

    @FXML
    private ImageView profilePicture;
    @FXML
    private TextField usernameField;
    @FXML
    private TextField emailField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private PasswordField confirmPasswordField;
    @FXML
    private DatePicker birthDatePicker;
    @FXML
    private Button cancelButton;
    @FXML
    private Button registerButton;
    @FXML
    private Text usernameErrorLabel;
    @FXML
    private Text emailErrorLabel;
    @FXML
    private Text passwordErrorLabel;
    @FXML
    private Text confirmErrorLabel;
    @FXML
    private Text dateErrorLabel;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        usernameField.textProperty().addListener((observable, oldValue, newValue) -> validateUsername());
        emailField.textProperty().addListener((observable, oldValue, newValue) -> validateEmail());
        passwordField.textProperty().addListener((observable, oldValue, newValue) -> validatePassword());
        confirmPasswordField.textProperty().addListener((observable, oldValue, newValue) -> validateConfirmPassword());
        birthDatePicker.valueProperty().addListener((observable, oldValue, newValue) -> validateBirthDate());
    }    

    /*----------- MÉTODOS ASOCIADOS A LOS BOTONES ----------------*/
    @FXML
    private void cancelRegisterPlayer(ActionEvent event) {
        /**MÉTODO PARA CERRAR EL REGISTRO*/
        Stage stage = (Stage) registerButton.getScene().getWindow(); // This assumes you're calling this from a button inside the Register window
        stage.close(); // This closes the window
    }

    @FXML
    private void registerAvatar(ActionEvent event) {
        /**METODO PARA CAMBIAR EL AVATAR EN REGISTRO*/
        FileChooser fileChooser = new FileChooser();

        // Set file extension filters for image files (e.g., JPG, PNG)
        FileChooser.ExtensionFilter imageFilter = new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png", "*.gif");
        fileChooser.getExtensionFilters().add(imageFilter);

        // Open the file chooser window
        Stage stage = (Stage) profilePicture.getScene().getWindow();
        File selectedFile = fileChooser.showOpenDialog(stage);

        // If a file was selected, update the ImageView with the new image
        if (selectedFile != null) {
            Image newAvatar = new Image(selectedFile.toURI().toString());
            profilePicture.setImage(newAvatar);  // Set the new avatar image
        }
    }

    @FXML
    private void registerPlayer(ActionEvent event) {
        /**MÉTODO PARA REGISTRAR UN NUEVO JUGADOR*/
        // Check if any validation errors are present
        boolean hasErrors = !usernameErrorLabel.getText().isEmpty() ||
                            !emailErrorLabel.getText().isEmpty() ||
                            !passwordErrorLabel.getText().isEmpty() ||
                            !confirmErrorLabel.getText().isEmpty() ||
                            !dateErrorLabel.getText().isEmpty();

        if (hasErrors) {
            // Display a message to fix errors (Optional: Add a popup or additional label for feedback)
            System.out.println("Fix the errors before proceeding.");
            return;
        }

        // Prepare data for database insertion
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();
        LocalDate birthDate = birthDatePicker.getValue();
        Image profileImage = profilePicture.getImage();

        // Mock database insertion logic (Replace with actual DB code)
        // e.g., database.insertUser(username, email, password, birthDate, profileImage);

        System.out.println("User registered successfully: " + username);

        // Close the registration window
        Stage stage = (Stage) registerButton.getScene().getWindow();
        stage.close();
    }
    
    
    /*----------- MÉTODOS ASOCIADOS AL INPUT DE VALORES ----------------*/
    
    //VALIDA SI TEXTO INTRODUCIDO EN INPUT DE USUARIO ES VÁLIDO
    private void validateUsername() {
        usernameErrorLabel.setVisible(true);
        String username = usernameField.getText().trim();

        // Check username availability (mocked for now)
        boolean isUsernameAvailable = true; // Replace with DB query logic to check availability.

        if (username.isEmpty()) {
            usernameErrorLabel.setText("Usuario no puede estar vacío.");
        } else if (!isUsernameAvailable) {
            usernameErrorLabel.setText("Usuario no está disponible");
        } else {
            usernameErrorLabel.setText(""); // Clear error if valid
        }
    }
    
    //VALIDA SI EMAIL INTRODUCIDO EN INPUT DE USUARIO ES VÁLIDO
    private void validateEmail() {
    emailErrorLabel.setVisible(true);
    String email = emailField.getText().trim();

    // Check email availability (mocked for now)
    boolean isEmailAvailable = true; // Replace with DB query logic to check availability.

    // Email validation regex: standard but simplified for common usage
    String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

    if (email.isEmpty()) {
        emailErrorLabel.setText("El email no puede estar vacío.");
    } else if (!email.matches(emailRegex)) {
        emailErrorLabel.setText("Formato de email incorrecto.");   
    } else if (!isEmailAvailable) {
        emailErrorLabel.setText("El email ya está en uso.");
    } else {
        emailErrorLabel.setText(""); // Clear error if valid
    }
}


    //VALIDA SI CONTRASEÑA ES VÁLIDA
    private void validatePassword() {
        passwordErrorLabel.setVisible(true);
        String password = passwordField.getText().trim();

        if (password.isEmpty()) {
            passwordErrorLabel.setText("Password cannot be empty.");
        } else if (password.length() < 8 || password.length() > 20) {
            passwordErrorLabel.setText("Password must be 8-20 characters long.");
        } else if (!password.matches(".*[!@#$%&*()\\-+=].*")) {
            passwordErrorLabel.setText("Password must contain at least one special character (!@#$%&*()-+=).");
        } else {
            passwordErrorLabel.setText(""); // Clear error if valid
        }
    }

    //VALIDA SI CONFIRMACIÓN CONTRA ES VÁLIDA
    private void validateConfirmPassword() {
        confirmErrorLabel.setVisible(true);
        String password = passwordField.getText().trim();
        String confirmPassword = confirmPasswordField.getText().trim();

        if (confirmPassword.isEmpty()) {
            confirmErrorLabel.setText("Confirm Password cannot be empty.");
        } else if (!confirmPassword.equals(password)) {
            confirmErrorLabel.setText("Passwords do not match.");
        } else {
            confirmErrorLabel.setText(""); // Clear error if valid
        }
    }

    // Method to validate birth date
    private void validateBirthDate() {
        dateErrorLabel.setVisible(true);
        LocalDate birthDate = birthDatePicker.getValue();

        if (birthDate == null) {
            dateErrorLabel.setText("Birth date cannot be empty.");
        } else {
            int age = Period.between(birthDate, LocalDate.now()).getYears();

            if (age < 12) {
                dateErrorLabel.setText("You must be at least 12 years old.");
            } else {
                dateErrorLabel.setText(""); // Clear error if valid
            }
        }
    }

    // Combined validation method for all fields
    public void validateAllFields() {
        validateUsername();
        validateEmail();
        validatePassword();
        validateConfirmPassword();
        validateBirthDate();
    }
}
