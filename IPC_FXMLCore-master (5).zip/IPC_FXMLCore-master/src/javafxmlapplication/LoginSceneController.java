/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxmlapplication;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Ramon
 */
public class LoginSceneController implements Initializable {

    @FXML
    private ImageView backgroundImage;
    @FXML
    private ImageView globalStatsIcon;
    @FXML
    private ImageView globalRankingsIcon;
    @FXML
    private ImageView player1EditProfileIcon;
    @FXML
    private TextField player1Username;
    @FXML
    private PasswordField player1Password;
    @FXML
    private Button player1ReadyButton;
    @FXML
    private ImageView player2EditProfileIcon;
    @FXML
    private TextField player2Username;
    @FXML
    private PasswordField player2Password;
    @FXML
    private CheckBox playAgainstAI;
    @FXML
    private Button player2ReadyButton;
    @FXML
    private Button playButton;
    @FXML
    private Hyperlink registerLink;
    @FXML
    private Label player1Display;
    @FXML
    private Label player2Display;
    
    
    boolean isPlayer1Ready = false;
    boolean isPlayer2Ready = false;
    
    boolean readyPlayer1AlreadyPressed = false;
    boolean readyPlayer2AlreadyPressed = false;
       
    
    @FXML
    private Text errorMessage1;
    @FXML
    private Text errorMessage2;

    /**
     * AQUÍ VA EL INITIALIZE
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //**BINDINGS ENTRE EL CHECKBOX DE LA IA Y LOS TEXTFIELDS DE INPUT PLAYER2*/
        //así, desactiva los inputs del player2 cuando se hace click en la checkbox de jugar como IA
        player2Password.disableProperty().bind(playAgainstAI.selectedProperty());
        player2Username.disableProperty().bind(playAgainstAI.selectedProperty());
        
    }    

    @FXML
    private void player1EditProfile(MouseEvent event) {
        //FALTA IMPLEMENTARLO, ES PARA APRETAR EL LOGIN
    }

    @FXML
    private void readyPlayer1(ActionEvent event) {
        /**MÉTODO CUANDO LE DAMOS AL READYPLAYER1 BUTTON ("INICIAR SESIÓN")*/
        if(!readyPlayer1AlreadyPressed) {
            readyPlayer1AlreadyPressed = true;
            handleLogin1(player1Username.getText(), player1Password.getText());
        }
        else {
            playButton.setDisable(true);
            
            player1Username.setText("");
            player1Password.setText("");
            
            readyPlayer1AlreadyPressed = false;
            isPlayer1Ready = false;
            
            player1ReadyButton.setText("Iniciar Sesión");
            
            
            player1Username.setDisable(false);
            player1Password.setDisable(false);
        }
        
    }
    
    @FXML
    private void readyPlayer2(ActionEvent event) {
         /**MÉTODO CUANDO LE DAMOS AL READYPLAYE2 BUTTON ("INICIAR SESIÓN")*/
         if(playAgainstAI.isSelected()) {
             player2ReadyButton.setText("Preparado");
             isPlayer2Ready = true;
             checkIfBothReady();
         }
         else if(!readyPlayer2AlreadyPressed) {
            readyPlayer2AlreadyPressed = true;
            handleLogin2(player1Username.getText(), player1Password.getText());
        }
        else {
            playButton.setDisable(true);
            
            player2Username.setText("");
            player2Password.setText("");
            
            readyPlayer2AlreadyPressed = false;
            isPlayer2Ready = false;
            
            player2ReadyButton.setText("Iniciar Sesión");
            
            
            player2Username.setDisable(false);
            player2Password.setDisable(false);
            playAgainstAI.setDisable(false);
        }
    }

    @FXML
    private void player2EditProfile(MouseEvent event) {
    }

    @FXML
    private void AIPlayer2(ActionEvent event) {
        if(playAgainstAI.isSelected()) {
            player2ReadyButton.setText("Preparado");
            isPlayer2Ready = true;
            checkIfBothReady();
        }
        else {
            player2ReadyButton.setText("Iniciar Sesión");
            isPlayer2Ready = false;
            

        }
    }

    

    @FXML
    private void registerPlayer(ActionEvent event) {
        try {
            // Load the Register FXML file (make sure the path is correct)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxmlapplication/RegisterPanel.fxml"));

            // Create the new Stage (subwindow)
            Stage registerStage = new Stage();
            registerStage.setTitle("Register");

            // Create a new Scene for the Register window
            Scene registerScene = new Scene(loader.load(), 400, 550); // Ensure the scene size matches your FXML dimensions
            registerStage.setScene(registerScene);

            // Set the window modality to BLOCK (so it will block interactions with the main window)
            registerStage.initModality(Modality.APPLICATION_MODAL);

            // Show the register window
            registerStage.show();
        } catch (Exception e) {
            // Handle errors in case loading FXML fails
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to open register window!");
            alert.show();
        }
    }
    
    
    
    public void handleRegisterLinkClick() {
        
    }

    
    
    private void handleLogin1(String username, String password) {
        boolean isValid = isValidUser(username, password);
        
        if(isValid) {
            player1Username.setDisable(true);
            player1Password.setDisable(true);
            player1ReadyButton.setText("Preparado");
            
            isPlayer1Ready = true;
            
            checkIfBothReady();
        }else {
            errorMessage1.setText("Usuario o contraseña no válidos");
            errorMessage1.setVisible(true);
        }
    }
    
    private void handleLogin2(String username, String password) {
        player2Username.disableProperty().unbind();
        player2Password.disableProperty().unbind();
        
        
        boolean isValid = isValidUser(username, password);
        
        if(isValid) {
            player2Username.setDisable(true);
            player2Password.setDisable(true);
            playAgainstAI.setDisable(true);
            player2ReadyButton.setText("Preparado");
            
            isPlayer2Ready = true;
            
            checkIfBothReady();
        }else {
            errorMessage2.setText("Usuario o contraseña no válidos");
            errorMessage2.setVisible(true);
        }
    }
    
    
    private void checkIfBothReady() {
        playButton.setDisable(!(isPlayer1Ready && isPlayer2Ready));
    }
    
    
    private boolean isValidUser(String username, String password) {
        //Comprueba si existe el usuario a iniciar sesión.
        //POR AHORA TODOS EXISTEN
        return true;
    }

    @FXML
    private void playButtonPressed(ActionEvent event) {
        try {
            // Load the Register FXML file (make sure the path is correct)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxmlapplication/MainBoardGame.fxml"));

            // Create the new Stage (subwindow)
            Stage registerStage = new Stage();
            registerStage.setTitle("Conecta4");

            // Create a new Scene for the Register window
            Scene registerScene = new Scene(loader.load(), 400, 550); // Ensure the scene size matches your FXML dimensions
            registerStage.setScene(registerScene);

            // Set the window modality to BLOCK (so it will block interactions with the main window)
            registerStage.initModality(Modality.APPLICATION_MODAL);

            // Show the register window
            registerStage.show();
            
            Stage stage = (Stage) playButton.getScene().getWindow(); // This assumes you're calling this from a button inside the Register window
            stage.close(); // This closes the window
        } catch (Exception e) {
            // Handle errors in case loading FXML fails
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to open register window!");
            alert.show();
        }
        
    }
}
