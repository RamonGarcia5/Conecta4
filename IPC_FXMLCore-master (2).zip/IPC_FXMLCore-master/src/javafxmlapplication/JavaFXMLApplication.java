/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxmlapplication;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class JavaFXMLApplication extends Application {
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Load the FXML file
        Parent root = FXMLLoader.load(getClass().getResource("LoginScene.fxml"));

        // Automatically set the scene size to the AnchorPane's preferred size
        double anchorWidth = root.prefWidth(-1);  // Get width from AnchorPane
        double anchorHeight = root.prefHeight(-1); // Get height from AnchorPane

        Scene scene = new Scene(root, anchorWidth, anchorHeight);

        // Set the scene to the stage
        primaryStage.setScene(scene);

        // Prevent resizing from breaking the aspect ratio
        double aspectRatio = anchorWidth / anchorHeight;

        primaryStage.widthProperty().addListener((obs, oldWidth, newWidth) -> {
            primaryStage.setHeight(newWidth.doubleValue() / aspectRatio);
        });

        primaryStage.heightProperty().addListener((obs, oldHeight, newHeight) -> {
            primaryStage.setWidth(newHeight.doubleValue() * aspectRatio);
        });

        // Enable decorations but restrict resizing to the set aspect ratio
        primaryStage.setResizable(true);

        // Set the title of the window
        primaryStage.setTitle("Connect 4");

        // Show the stage
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}