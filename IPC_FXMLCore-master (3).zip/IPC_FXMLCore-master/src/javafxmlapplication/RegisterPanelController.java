/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxmlapplication;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Ramon
 */
public class RegisterPanelController implements Initializable {

    @FXML
    private ImageView profilePicture;
    @FXML
    private TextField usernameField;
    @FXML
    private TextField emailField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private PasswordField confirmPasswordField;
    @FXML
    private DatePicker birthDatePicker;
    @FXML
    private Button cancelButton;
    @FXML
    private Button registerButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    


    @FXML
    private void cancelRegisterPlayer(ActionEvent event) {
        Stage stage = (Stage) registerButton.getScene().getWindow(); // This assumes you're calling this from a button inside the Register window
        stage.close(); // This closes the window
    }

    @FXML
    private void registerAvatar(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();

        // Set file extension filters for image files (e.g., JPG, PNG)
        FileChooser.ExtensionFilter imageFilter = new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png", "*.gif");
        fileChooser.getExtensionFilters().add(imageFilter);

        // Open the file chooser window
        Stage stage = (Stage) profilePicture.getScene().getWindow();
        File selectedFile = fileChooser.showOpenDialog(stage);

        // If a file was selected, update the ImageView with the new image
        if (selectedFile != null) {
            Image newAvatar = new Image(selectedFile.toURI().toString());
            profilePicture.setImage(newAvatar);  // Set the new avatar image
        }
    }

    @FXML
    private void registerPlayer(ActionEvent event) {
    }
    
}
