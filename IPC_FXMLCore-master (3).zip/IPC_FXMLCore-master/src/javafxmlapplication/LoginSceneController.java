/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxmlapplication;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Ramon
 */
public class LoginSceneController implements Initializable {

    @FXML
    private ImageView backgroundImage;
    @FXML
    private ImageView globalStatsIcon;
    @FXML
    private ImageView globalRankingsIcon;
    @FXML
    private ImageView player1EditProfileIcon;
    @FXML
    private TextField player1Username;
    @FXML
    private PasswordField player1Password;
    @FXML
    private Button player1ReadyButton;
    @FXML
    private ImageView player2EditProfileIcon;
    @FXML
    private TextField player2Username;
    @FXML
    private PasswordField player2Password;
    @FXML
    private CheckBox playAgainstAI;
    @FXML
    private Button player2ReadyButton;
    @FXML
    private Button playButton;
    @FXML
    private Hyperlink registerLink;
    @FXML
    private Text errorMessagePlayer1;
    @FXML
    private Text errorMessagePlayer2;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //**BINDINGS ENTRE EL CHECKBOX DE LA IA Y LOS TEXTFIELDS DE INPUT PLAYER2*/
        player2Password.disableProperty().bind(playAgainstAI.selectedProperty());
        player2Username.disableProperty().bind(playAgainstAI.selectedProperty());
        
    }    

    @FXML
    private void player1EditProfile(MouseEvent event) {
        
    }

    @FXML
    private void readyPlayer1(ActionEvent event) {
        /**HA DE COMPROBAR EL PLAYER1 EN LA BASE DE DATOS*/
    }
    
    @FXML
    private void readyPlayer2(ActionEvent event) {
         /**HA DE COMPROBAR EL PLAYER2 EN LA BASE DE DATOS*/
    }

    @FXML
    private void player2EditProfile(MouseEvent event) {
    }

    @FXML
    private void AIPlayer2(ActionEvent event) {
        
    }

    

    @FXML
    private void registerPlayer(ActionEvent event) {
        try {
            // Load the Register FXML file (make sure the path is correct)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/javafxmlapplication/RegisterPanel.fxml"));

            // Create the new Stage (subwindow)
            Stage registerStage = new Stage();
            registerStage.setTitle("Register");

            // Create a new Scene for the Register window
            Scene registerScene = new Scene(loader.load(), 400, 550); // Ensure the scene size matches your FXML dimensions
            registerStage.setScene(registerScene);

            // Set the window modality to BLOCK (so it will block interactions with the main window)
            registerStage.initModality(Modality.APPLICATION_MODAL);

            // Show the register window
            registerStage.show();
        } catch (Exception e) {
            // Handle errors in case loading FXML fails
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to open register window!");
            alert.show();
        }
    }
    
    
    
    public void handleRegisterLinkClick() {
        
    }
    
}
